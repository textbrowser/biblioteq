#!/usr/bin/bash

if [ $ALT_XBOOK ]
then
    echo "Using ALT_XBOOK."
    export XFILESEARCHPATH=$XFILESEARCHPATH:~/app-defaults/xbook
    $ALT_XBOOK/xbook.bin love $ALT_XBOOK &
else
    export XFILESEARCHPATH=$XFILESEARCHPATH:/usr/local/app-defaults/xbook
    /usr/local/bin/xbook.bin love /usr/local/bin &
fi
