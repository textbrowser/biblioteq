GRANT ALL ON xbook_db.* TO xbook_user@love.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@gauss.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@galois.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@willow.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@horse.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@megatron.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@localhost IDENTIFIED BY "xbook_user";
