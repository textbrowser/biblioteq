GRANT ALL ON xbook_db.* TO xbook_user@love.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@gauss.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@galois.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@willow.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@horse.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@megatron.monster.org IDENTIFIED BY "xbook_user";
GRANT ALL ON xbook_db.* TO xbook_user@localhost IDENTIFIED BY "xbook_user";

USE xbook_db;

CREATE TABLE book
(
	isbn		VARCHAR(32) NOT NULL PRIMARY KEY,
	title		LONGTEXT NOT NULL,
	edition		VARCHAR(8) NOT NULL,
	author		LONGTEXT NOT NULL,
	pdate		VARCHAR(32) NOT NULL,
	publisher	LONGTEXT NOT NULL,
	category	VARCHAR(64) NOT NULL,
	price		FLOAT NOT NULL,
	description	LONGTEXT NOT NULL,
	language	VARCHAR(64) NOT NULL,
	monetary_units	VARCHAR(64) NOT NULL
);
